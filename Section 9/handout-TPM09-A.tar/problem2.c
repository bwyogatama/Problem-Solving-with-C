#include <stdio.h>
#include <stdlib.h>

int main(void)
{

	printf("Masukkan jumlah elemen pada array :\n");

    printf("Masukkan elemen ke-% :\n");

	printf("Array yang tersusun secara ascending :\n");

  return 0;
}
