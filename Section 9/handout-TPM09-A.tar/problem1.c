#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	//Deklarasi Variabel

	//Input Panjang Karakter
    printf("Masukkan panjang karakter dari kalimat :\n");

	//Input Kalimat
    printf("Masukkan sebuah kalimat :\n");

	//Cetak Output
    printf("Kalimat yang dimasukkan adalah : %\n");
    return 0;
}
