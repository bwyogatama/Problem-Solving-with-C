#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	//Deklarasi Variable

	//Input Orde Matriks
    printf("Masukkan orde matriks pertama :\n");
    printf("Masukkan orde matriks kedua :\n");

	//Alokasi Memori
	
	
	//Cek Orde Matriks
    printf("Orde matriks yang dimasukkan salah!\n");

	//Input Nilai matriks pertama
    printf("Masukkan elemen (%, %) dari matriks pertama :\n");

	//Input Nilai matriks kedua
    printf("Masukkan elemen (%, %) dari matriks kedua :\n");

	//Cetak Matriks Pertama
    printf("Matriks pertama :\n");
    printf("%d\t");
    printf("\n");

	//Cetak Matriks kedua
    printf("Matriks kedua :\n");
    printf("%d\t");
    printf("\n");

	//Cetak Matriks hasil perkalian
    printf("Hasil perkalian matriks :\n");
    printf("%d\t");
    printf("\n");

    return 0;
}
