#include <stdio.h>  /* Library for standard input and output in command prompt screen */
#include <stdlib.h> /* Library for memory allocation in dynamic array */



// Deklarasi Prosedur atau fungsi disini (opsional)



/* Program Utama */
int main(void)
{
  /* Variabel */

  /* Input */
  printf("Masukkan jumlah data : \n");


  /* Menghitung nilai nol di faktorial */
    printf("Masukkan faktorial ke-%d : \n");

  
  /* Keluaran pada layar tanpa sorting */
  printf("**Tanpa Sorting**\n");
  printf("Faktorial\tNol\n");

    printf("%d\t\t%d\n");

  
  /* Proses sorting ascending */

  
  /* Keluaran pada layar dengan sorting */
  printf("**Dengan Sorting**\n");
  printf("Faktorial\tNol\n");

    printf("%d\t\t%d\n");

  
  /* Menghitung rata-rata */

  printf("Rata-rata angka nol : %.3f\n");
  
  /* Melepas memory */

  return 0;
}


// Definisi Prosedur atau fungsi disini (opsional)

