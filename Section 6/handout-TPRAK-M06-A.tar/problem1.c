#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{

	printf("Masukkan kalimat ke1 :\n");
	printf("Masukkan kalimat ke2 :\n");

		printf("Kedua kalimat sama\n");

		printf("Kedua kalimat tidak sama\n");

	return 0;
}
