#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{

	printf("Masukkan kata :\n");

		printf("Huruf tengah dari kata \"%\" adalah %%\n");

		printf("Huruf tengah dari kata \"%\" adalah %\n");


	return 0;
}
