#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{

	printf("Masukkan nama ke% : \n");

	printf("Berikut ini list 10 nama setelah diurutkan ascending\n");

	printf("\t%\n");

	return 0;
}