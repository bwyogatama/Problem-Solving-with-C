#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{

	printf("Masukkan kata :\n");

	printf("Kata \"%\" bukan palindrom\n");

	printf("Kata \"%\" palindrom\n");


	return 0;
}
