#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{

	printf("Masukkan kalimat :\n");
	printf("Masukkan kata yang dicari :\n");
	
		printf("Kata % ada didalam kalimat \"%\"\n");

		printf("Kata % tidak ada didalam kalimat \"%\"\n");

	return 0;
}
