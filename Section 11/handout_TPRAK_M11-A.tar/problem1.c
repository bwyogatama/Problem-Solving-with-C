#include <stdio.h>

//Deklarasi tipe data bentukan

//Deklarasi prosedur atau fungsi

int main()
{

    printf("INPUT : \n");
 
    printf("%.2f\n");

return(0);
}

//Definisi Prosedur atau fungsi


