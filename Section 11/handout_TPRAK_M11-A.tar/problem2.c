#include <stdio.h>
#include <math.h>

int main()
{
    
    printf("Input biner ke-%d : \n",i);
  
    printf("Hasil : %s\n",enc);

	return(0);
}




